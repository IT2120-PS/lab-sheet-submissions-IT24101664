setwd("C:\\Users\\IT24101664\\Desktop\\IT24101664")
getwd()


branch_data <- read.csv("Exercise.txt",header = TRUE)
print(head(branch_data))

boxplot(branch_data$Sales_X1,
        main = "Boxpot of sales" ,
        ylab = "sales")

summary(branch_data$Advertising_x2)
IQR(branch_data$Advertising_X2)

find_otliers <- function(x) {
  q1 <- quantile(x,0.25)
  q3 <- quantile(x,0.75)
  iqr <- q3 -q1
  lower_bound <- q1 - 1.5*iqr
  upper_bound <- q3 + 1.5*iqr
  outliers <-x[x<lower_bound | x>upper_bound]
  return(outliers)
}


outliers_years <- find_otliers(branch_data$Years_X3)
print(outliers_years)
SS
