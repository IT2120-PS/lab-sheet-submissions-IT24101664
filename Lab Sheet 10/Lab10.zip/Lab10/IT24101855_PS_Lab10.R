setwd("C:\\Users\\thine\\OneDrive\\Desktop\\Lab10")
getwd()
observed <- c(120, 95, 85, 100)
chisq.test(x=observed)
file_path <- "Data.csv"

snacks <- read.csv(file_path, row.names = 1)
snacks

chisq.test(snacks)
